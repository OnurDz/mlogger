#include "ros/ros.h"
#include "std_msgs/String.h"
#include "rosgraph_msgs/Log.h"
#include "ros/console.h"

void loggerCallback(const rosgraph_msgs::Log::ConstPtr& msg) {
    if(ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug))
        ros::console::notifyLoggerLevelsChanged();

    std::string this_node_name = ros::this_node::getName();
    if(msg->name.compare(this_node_name) != 0)
        if(msg->level == msg->DEBUG) {
            ROS_DEBUG("%d in node %s at function %s: \"%s\"", msg->level, msg->name.c_str(), msg->function.c_str(), msg->msg.c_str());
        } else if(msg->level == msg->INFO) {
            ROS_INFO("%d in node %s at function %s: \"%s\"", msg->level, msg->name.c_str(), msg->function.c_str(), msg->msg.c_str());
        } else if(msg->level == msg->WARN) {
            ROS_WARN("%d in node %s at function %s: \"%s\"", msg->level, msg->name.c_str(), msg->function.c_str(), msg->msg.c_str());
        } else if(msg->level == msg->ERROR) {
            ROS_ERROR("%d in node %s at function %s: \"%s\"", msg->level, msg->name.c_str(), msg->function.c_str(), msg->msg.c_str());
        } else if(msg->level == msg->FATAL) {
            ROS_FATAL("%d in node %s at function %s: \"%s\"", msg->level, msg->name.c_str(), msg->function.c_str(), msg->msg.c_str());
        }
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "log_listener");
    ros::NodeHandle n;
    ros::Subscriber sub = n.subscribe("/rosout_agg", 1024, loggerCallback);
    ros::spin();
    return 0;
}
